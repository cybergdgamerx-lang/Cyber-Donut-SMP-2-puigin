package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.OfflinePlayer;

import java.util.List;
import java.util.UUID;

/**
 * Exposes CDS2Core's economy to Vault. Vault speaks in doubles; we convert to whole cents
 * and reject NaN / infinite / negative / oversized values before touching any balance.
 * Legacy name-based methods only resolve names we've stored (never a Mojang lookup).
 */
public final class VaultEconomyProvider implements Economy {

    private static final String NO_BANKS = "CDS2Core has no bank support.";

    private final EconomyManager eco;

    public VaultEconomyProvider(CDS2Core plugin) {
        this.eco = plugin.economy();
    }

    // ---------- helpers ----------

    private static boolean valid(double amount) {
        return !Double.isNaN(amount) && !Double.isInfinite(amount) && amount >= 0
                && amount * 100.0 <= EconomyManager.MAX_AMOUNT;
    }

    private static long cents(double amount) { return Math.round(amount * 100.0); }
    private double bal(UUID id) { return eco.getBalance(id) / 100.0; }
    private UUID byName(String name) { return name == null ? null : eco.resolve(name); }

    private EconomyResponse fail(UUID id, String msg) {
        return new EconomyResponse(0, id == null ? 0 : bal(id), ResponseType.FAILURE, msg);
    }

    private EconomyResponse withdraw(UUID id, double amount) {
        if (!valid(amount)) return fail(id, "Invalid amount.");
        if (id == null || !eco.hasAccount(id)) return fail(id, "No account.");
        long c = cents(amount);
        if (c > 0 && !eco.withdraw(id, c)) return fail(id, "Insufficient funds.");
        return new EconomyResponse(amount, bal(id), ResponseType.SUCCESS, "");
    }

    private EconomyResponse deposit(UUID id, String nameOrNull, double amount) {
        if (!valid(amount)) return fail(id, "Invalid amount.");
        if (id == null) return fail(null, "No account.");
        eco.ensureAccount(id, nameOrNull);
        eco.deposit(id, cents(amount));
        return new EconomyResponse(amount, bal(id), ResponseType.SUCCESS, "");
    }

    private boolean createAccount(UUID id, String nameOrNull) {
        if (id == null) return false;
        boolean existed = eco.hasAccount(id);
        eco.ensureAccount(id, nameOrNull);
        return !existed;
    }

    // ---------- general ----------

    @Override public boolean isEnabled() { return true; }
    @Override public String getName() { return "CDS2Core"; }
    @Override public boolean hasBankSupport() { return false; }
    @Override public int fractionalDigits() { return 2; }
    @Override public String format(double amount) { return Msg.money(cents(amount)); }
    @Override public String currencyNamePlural() { return "dollars"; }
    @Override public String currencyNameSingular() { return "dollar"; }

    // ---------- accounts ----------

    @Override @Deprecated public boolean hasAccount(String playerName) { UUID id = byName(playerName); return id != null && eco.hasAccount(id); }
    @Override public boolean hasAccount(OfflinePlayer player) { return eco.hasAccount(player.getUniqueId()); }
    @Override @Deprecated public boolean hasAccount(String playerName, String worldName) { return hasAccount(playerName); }
    @Override public boolean hasAccount(OfflinePlayer player, String worldName) { return hasAccount(player); }

    @Override @Deprecated public boolean createPlayerAccount(String playerName) { return false; } // can't create without a UUID
    @Override public boolean createPlayerAccount(OfflinePlayer player) { return createAccount(player.getUniqueId(), player.getName()); }
    @Override @Deprecated public boolean createPlayerAccount(String playerName, String worldName) { return false; }
    @Override public boolean createPlayerAccount(OfflinePlayer player, String worldName) { return createPlayerAccount(player); }

    // ---------- balance ----------

    @Override @Deprecated public double getBalance(String playerName) { UUID id = byName(playerName); return id == null ? 0 : bal(id); }
    @Override public double getBalance(OfflinePlayer player) { return bal(player.getUniqueId()); }
    @Override @Deprecated public double getBalance(String playerName, String world) { return getBalance(playerName); }
    @Override public double getBalance(OfflinePlayer player, String world) { return getBalance(player); }

    @Override @Deprecated public boolean has(String playerName, double amount) { UUID id = byName(playerName); return id != null && valid(amount) && eco.has(id, cents(amount)); }
    @Override public boolean has(OfflinePlayer player, double amount) { return valid(amount) && eco.has(player.getUniqueId(), cents(amount)); }
    @Override @Deprecated public boolean has(String playerName, String worldName, double amount) { return has(playerName, amount); }
    @Override public boolean has(OfflinePlayer player, String worldName, double amount) { return has(player, amount); }

    // ---------- withdraw / deposit ----------

    @Override @Deprecated public EconomyResponse withdrawPlayer(String playerName, double amount) { return withdraw(byName(playerName), amount); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) { return withdraw(player.getUniqueId(), amount); }
    @Override @Deprecated public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) { return withdrawPlayer(playerName, amount); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) { return withdrawPlayer(player, amount); }

    @Override @Deprecated public EconomyResponse depositPlayer(String playerName, double amount) { return deposit(byName(playerName), null, amount); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer player, double amount) { return deposit(player.getUniqueId(), player.getName(), amount); }
    @Override @Deprecated public EconomyResponse depositPlayer(String playerName, String worldName, double amount) { return depositPlayer(playerName, amount); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) { return depositPlayer(player, amount); }

    // ---------- banks (unsupported) ----------

    private static EconomyResponse noBanks() { return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, NO_BANKS); }

    @Override @Deprecated public EconomyResponse createBank(String name, String player) { return noBanks(); }
    @Override public EconomyResponse createBank(String name, OfflinePlayer player) { return noBanks(); }
    @Override public EconomyResponse deleteBank(String name) { return noBanks(); }
    @Override public EconomyResponse bankBalance(String name) { return noBanks(); }
    @Override public EconomyResponse bankHas(String name, double amount) { return noBanks(); }
    @Override public EconomyResponse bankWithdraw(String name, double amount) { return noBanks(); }
    @Override public EconomyResponse bankDeposit(String name, double amount) { return noBanks(); }
    @Override @Deprecated public EconomyResponse isBankOwner(String name, String playerName) { return noBanks(); }
    @Override public EconomyResponse isBankOwner(String name, OfflinePlayer player) { return noBanks(); }
    @Override @Deprecated public EconomyResponse isBankMember(String name, String playerName) { return noBanks(); }
    @Override public EconomyResponse isBankMember(String name, OfflinePlayer player) { return noBanks(); }
    @Override public List<String> getBanks() { return List.of(); }
}
