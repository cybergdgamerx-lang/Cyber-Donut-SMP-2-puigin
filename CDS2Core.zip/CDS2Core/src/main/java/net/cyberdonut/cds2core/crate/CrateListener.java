package net.cyberdonut.cds2core.crate;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class CrateListener implements Listener {

    private static final BlockFace[] SIDES = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
    private final CDS2Core plugin;

    public CrateListener(CDS2Core plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Block block = e.getClickedBlock();
        if (block == null) return;
        Action action = e.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.LEFT_CLICK_BLOCK) return;
        Crate crate = plugin.crates().getCrateAt(block);
        if (crate == null) return;

        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(Event.Result.DENY);
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!p.hasPermission("cds2.crate.use")) return;

        if (action == Action.LEFT_CLICK_BLOCK) {
            new CratePreviewMenu(plugin, crate).open(p);
            return;
        }

        CrateManager cm = plugin.crates();
        ItemStack hand = p.getInventory().getItemInMainHand();
        String keyCrate = cm.getKeyCrateId(hand);
        if (keyCrate == null || !keyCrate.equals(crate.id())) {
            Msg.send(p, "<red>You need a <crate> <red>key. <gray>Left-click to preview rewards.", net.kyori.adventure.text.minimessage.tag.resolver.Placeholder.parsed("crate", crate.display()));
            p.playSound(p.getLocation(), Sound.BLOCK_CHEST_LOCKED, 1f, 1f);
            return;
        }
        if (cm.isOpening(p.getUniqueId())) {
            Msg.send(p, "<red>You're already opening a crate.");
            return;
        }
        // Consume exactly one key BEFORE anything else happens.
        if (hand.getAmount() <= 1) {
            p.getInventory().setItemInMainHand(null);
        } else {
            ItemStack rest = hand.clone();
            rest.setAmount(hand.getAmount() - 1);
            p.getInventory().setItemInMainHand(rest);
        }
        cm.open(p, crate);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        if (!plugin.crates().isCrateBlock(e.getBlock())) return;
        e.setCancelled(true);
        Msg.send(e.getPlayer(), "<red>This is a crate. Admins can remove it with <white>/crate remove<red>.");
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent e) {
        Material t = e.getBlockPlaced().getType();
        if (t != Material.CHEST && t != Material.TRAPPED_CHEST) return;
        for (BlockFace f : SIDES) {
            if (plugin.crates().isCrateBlock(e.getBlockPlaced().getRelative(f))) {
                e.setCancelled(true); // would merge into a double chest next to a crate
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(plugin.crates()::isCrateBlock);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(plugin.crates()::isCrateBlock);
    }
}
