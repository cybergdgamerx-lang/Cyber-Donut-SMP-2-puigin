package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.FileIO;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/**
 * Balances are stored as whole CENTS (long) - no floating point drift.
 * Mutations are synchronized; the file is written atomically (temp file + move).
 */
public final class EconomyManager {

    public static final long MAX_AMOUNT = 100_000_000_000_000L;      // $1,000,000,000,000 per transaction
    public static final long MAX_BALANCE = 100_000_000_000_000_000L; // hard cap per account
    private static final Pattern NUMBER = Pattern.compile("^\\d{1,15}(\\.\\d{1,8})?$");

    private final CDS2Core plugin;
    private final File file;
    private final Map<UUID, Long> balances = new ConcurrentHashMap<>();
    private final Map<UUID, String> names = new ConcurrentHashMap<>();
    private final AtomicBoolean dirty = new AtomicBoolean(false);

    public EconomyManager(CDS2Core plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "balances.yml");
    }

    // ---------- persistence ----------

    public void load() {
        balances.clear();
        names.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yml.getConfigurationSection("players");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                balances.put(id, Math.max(0L, sec.getLong(key + ".balance")));
                String name = sec.getString(key + ".name");
                if (name != null) names.put(id, name);
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Skipping invalid UUID in balances.yml: " + key);
            }
        }
        plugin.getLogger().info("Loaded " + balances.size() + " accounts.");
    }

    public void startAutosave() {
        long ticks = Math.max(1, plugin.getConfig().getInt("settings.autosave-minutes", 2)) * 60L * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> save(true), ticks, ticks);
    }

    public void save(boolean async) {
        if (!dirty.getAndSet(false)) return;
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : balances.entrySet()) {
            String path = "players." + e.getKey();
            yml.set(path + ".balance", e.getValue());
            String name = names.get(e.getKey());
            if (name != null) yml.set(path + ".name", name);
        }
        String data = yml.saveToString();
        if (async) FileIO.saveAsync(plugin, file, data);
        else FileIO.writeAtomic(file, data);
    }

    // ---------- accounts ----------

    public void createAccount(UUID id, String name) {
        String old = names.put(id, name);
        boolean created = balances.putIfAbsent(id, startingCents()) == null;
        if (created || !name.equals(old)) dirty.set(true);
    }

    /** Creates the account if missing. A null name keeps whatever name is already stored. */
    public void ensureAccount(UUID id, String nameOrNull) {
        if (nameOrNull != null) {
            createAccount(id, nameOrNull);
        } else if (balances.putIfAbsent(id, startingCents()) == null) {
            dirty.set(true);
        }
    }

    private long startingCents() {
        return Math.max(0L, Math.round(plugin.getConfig().getDouble("economy.starting-balance", 1000.0) * 100.0));
    }

    public boolean hasAccount(UUID id) { return balances.containsKey(id); }
    public long getBalance(UUID id) { return balances.getOrDefault(id, 0L); }
    public String name(UUID id) { return names.getOrDefault(id, "Unknown"); }

    public boolean has(UUID id, long cents) { return getBalance(id) >= cents; }

    public synchronized boolean withdraw(UUID id, long cents) {
        if (cents <= 0) return false;
        long bal = getBalance(id);
        if (bal < cents) return false;
        balances.put(id, bal - cents);
        dirty.set(true);
        return true;
    }

    public synchronized void deposit(UUID id, long cents) {
        if (cents <= 0) return;
        long next = getBalance(id) + cents;
        if (next < 0 || next > MAX_BALANCE) next = MAX_BALANCE;
        balances.put(id, next);
        dirty.set(true);
    }

    public synchronized void set(UUID id, long cents) {
        balances.put(id, Math.max(0L, Math.min(cents, MAX_BALANCE)));
        dirty.set(true);
    }

    public synchronized boolean transfer(UUID from, UUID to, long cents) {
        if (!withdraw(from, cents)) return false;
        deposit(to, cents);
        return true;
    }

    // ---------- lookups ----------

    /** Resolves online players first, then names we've stored. Never contacts Mojang. */
    public UUID resolve(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        for (Map.Entry<UUID, String> e : names.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    /** Thread-safe snapshot sort; intended for async use. */
    public List<Map.Entry<UUID, Long>> top(int limit) {
        return balances.entrySet().stream()
                .map(e -> Map.entry(e.getKey(), e.getValue()))
                .sorted(Map.Entry.<UUID, Long>comparingByValue().reversed())
                .limit(limit)
                .toList();
    }

    /** 1-based rank; intended for async use. */
    public int rank(UUID id) {
        long mine = getBalance(id);
        int higher = 0;
        for (long v : balances.values()) if (v > mine) higher++;
        return higher + 1;
    }

    // ---------- parsing ----------

    /** Parses "100", "2.5k", "1m", "3b", "1t" into cents. Returns -1 when invalid / <= 0 / too large. */
    public static long parseAmount(String raw) {
        if (raw == null || raw.isBlank()) return -1;
        String s = raw.trim().toLowerCase(Locale.ROOT).replace(",", "");
        BigDecimal mult = BigDecimal.ONE;
        switch (s.charAt(s.length() - 1)) {
            case 'k' -> mult = BigDecimal.valueOf(1_000L);
            case 'm' -> mult = BigDecimal.valueOf(1_000_000L);
            case 'b' -> mult = BigDecimal.valueOf(1_000_000_000L);
            case 't' -> mult = BigDecimal.valueOf(1_000_000_000_000L);
            default -> { }
        }
        if (!mult.equals(BigDecimal.ONE)) s = s.substring(0, s.length() - 1);
        if (!NUMBER.matcher(s).matches()) return -1; // rejects negatives, NaN, exponents, garbage
        try {
            BigDecimal cents = new BigDecimal(s).multiply(mult).setScale(2, RoundingMode.DOWN).movePointRight(2);
            if (cents.signum() <= 0 || cents.compareTo(BigDecimal.valueOf(MAX_AMOUNT)) > 0) return -1;
            return cents.longValueExact();
        } catch (ArithmeticException | NumberFormatException ex) {
            return -1;
        }
    }
}
