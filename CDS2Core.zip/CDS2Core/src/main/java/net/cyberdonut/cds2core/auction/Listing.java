package net.cyberdonut.cds2core.auction;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public record Listing(UUID id, UUID seller, String sellerName, ItemStack item, long priceCents, long createdAt, long expiresAt) {}
