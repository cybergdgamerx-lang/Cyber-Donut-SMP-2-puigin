package net.cyberdonut.cds2core.crate;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public final class KeyCommand implements TabExecutor {

    private final CDS2Core plugin;

    public KeyCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length != 4 || !args[0].equalsIgnoreCase("give")) {
            Msg.send(sender, "<red>Usage: <white>/key give <player> <crate_type> <amount>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            Msg.send(sender, "<red>That player is not online.");
            return true;
        }
        Crate crate = plugin.crates().getCrate(args[2]);
        if (crate == null) {
            Msg.send(sender, "<red>Unknown crate. Available: <white><list>", Msg.text("list", String.join(", ", plugin.crates().crateIds())));
            return true;
        }
        int amount;
        try {
            amount = Integer.parseInt(args[3]);
        } catch (NumberFormatException ex) {
            amount = -1;
        }
        if (amount < 1 || amount > 2304) {
            Msg.send(sender, "<red>Amount must be between 1 and 2304.");
            return true;
        }
        plugin.crates().giveKeys(target, crate, amount);
        Msg.send(sender, "<green>Gave <white><n>x <crate> <green>key(s) to <white><p><green>.",
                Placeholder.unparsed("n", String.valueOf(amount)), Placeholder.parsed("crate", crate.display()), Msg.text("p", target.getName()));
        Msg.send(target, "<gray>You received <white><n>x <crate> <gray>key(s)!",
                Placeholder.unparsed("n", String.valueOf(amount)), Placeholder.parsed("crate", crate.display()));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return switch (args.length) {
            case 1 -> Tab.filter(List.of("give"), args[0]);
            case 2 -> Tab.online(args[1]);
            case 3 -> Tab.filter(plugin.crates().crateIds(), args[2]);
            case 4 -> Tab.filter(List.of("1", "5", "10", "64"), args[3]);
            default -> List.of();
        };
    }
}
