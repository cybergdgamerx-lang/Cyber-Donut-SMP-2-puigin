package net.cyberdonut.cds2core.crate;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.gui.CDSMenu;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;
import java.util.Locale;

public final class CratePreviewMenu extends CDSMenu {

    public CratePreviewMenu(CDS2Core plugin, Crate crate) {
        super(plugin);
        int n = Math.min(45, crate.rewards().size());
        int rows = Math.min(6, (n + 8) / 9 + 1);
        init(rows * 9, Msg.parse(crate.display() + " <dark_gray>- <gray>Rewards"));
        for (int i = 0; i < n; i++) {
            Reward r = crate.rewards().get(i);
            double chance = r.weight() / crate.totalWeight() * 100.0;
            getInventory().setItem(i, ItemBuilder.appendLore(r.iconCopy(), List.of(
                    Component.empty(),
                    Msg.noItalic("<gray>Chance: <yellow><c>%", Msg.text("c", String.format(Locale.US, "%.2f", chance))))));
        }
        getInventory().setItem(rows * 9 - 5, new ItemBuilder(Material.BARRIER).name("<red>Close").build());
        fillEmpty();
    }

    @Override
    public void onClick(Player player, InventoryClickEvent event) {
        if (event.getCurrentItem() != null && event.getCurrentItem().getType() == Material.BARRIER) player.closeInventory();
    }
}
