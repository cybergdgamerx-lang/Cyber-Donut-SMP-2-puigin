package net.cyberdonut.cds2core.util;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;

import java.util.Locale;

/** Central MiniMessage helper. Always pass player-supplied text through unparsed placeholders. */
public final class Msg {

    public static final MiniMessage MM = MiniMessage.miniMessage();
    public static final String PREFIX = "<gradient:#FF5555:#FFAA00><bold>[CDS2]</bold></gradient> <dark_gray>» ";

    private Msg() {}

    public static Component parse(String template, TagResolver... resolvers) {
        return MM.deserialize(template, resolvers);
    }

    /** Parsed component with italics forced off (for item names / lore). */
    public static Component noItalic(String template, TagResolver... resolvers) {
        return MM.deserialize(template, resolvers).decoration(TextDecoration.ITALIC, false);
    }

    public static void send(Audience audience, String template, TagResolver... resolvers) {
        audience.sendMessage(MM.deserialize(PREFIX + template, resolvers));
    }

    public static void broadcast(String template, TagResolver... resolvers) {
        Bukkit.getServer().broadcast(MM.deserialize(PREFIX + template, resolvers));
    }

    public static TagResolver text(String key, String value) {
        return Placeholder.unparsed(key, value);
    }

    public static TagResolver money(String key, long cents) {
        return Placeholder.unparsed(key, money(cents));
    }

    public static String money(long cents) {
        return "$" + String.format(Locale.US, "%,.2f", cents / 100.0);
    }

    public static String duration(long millis) {
        long m = millis / 60_000L;
        if (m < 1) return "<1m";
        long h = m / 60; m %= 60;
        long d = h / 24; h %= 24;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }
}
