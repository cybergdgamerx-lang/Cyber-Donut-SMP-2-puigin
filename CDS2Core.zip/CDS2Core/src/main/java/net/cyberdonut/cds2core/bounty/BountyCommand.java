package net.cyberdonut.cds2core.bounty;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.economy.EconomyManager;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public final class BountyCommand implements TabExecutor {

    private final CDS2Core plugin;

    public BountyCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
            List<Bounty> top = plugin.bounties().top(Math.max(1, plugin.getConfig().getInt("bounty.list-size", 10)));
            if (top.isEmpty()) {
                Msg.send(sender, "<gray>There are no active bounties.");
                return true;
            }
            sender.sendMessage(Msg.parse("<gradient:#FF5555:#FFAA00><bold>══ Active Bounties ══</bold></gradient>"));
            int i = 1;
            for (Bounty b : top) {
                sender.sendMessage(Msg.parse("<gray>#<i> <red><name> <dark_gray>- <gold><amt>",
                        Placeholder.unparsed("i", String.valueOf(i++)), Msg.text("name", b.targetName()), Msg.money("amt", b.amountCents())));
            }
            return true;
        }
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "<red>Only players can place bounties.");
            return true;
        }
        if (args.length != 2) {
            Msg.send(p, "<red>Usage: <white>/bounty <player> <amount> <gray>or <white>/bounty list");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            Msg.send(p, "<red>That player is not online.");
            return true;
        }
        if (target.getUniqueId().equals(p.getUniqueId())) {
            Msg.send(p, "<red>You can't place a bounty on yourself.");
            return true;
        }
        long cents = EconomyManager.parseAmount(args[1]);
        long min = Math.round(plugin.getConfig().getDouble("bounty.min-amount", 100.0) * 100);
        if (cents <= 0) {
            Msg.send(p, "<red>Invalid amount.");
            return true;
        }
        if (cents < min) {
            Msg.send(p, "<red>The minimum bounty is <white><min><red>.", Msg.money("min", min));
            return true;
        }
        if (!plugin.economy().withdraw(p.getUniqueId(), cents)) {
            Msg.send(p, "<red>You don't have enough money.");
            return true;
        }
        long total = plugin.bounties().add(target.getUniqueId(), target.getName(), cents);
        Msg.broadcast("<white><placer> <gray>placed a <gold><amt> <gray>bounty on <red><target><gray>! Total: <gold><total>",
                Msg.text("placer", p.getName()), Msg.money("amt", cents), Msg.text("target", target.getName()), Msg.money("total", total));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            List<String> opts = new java.util.ArrayList<>(Tab.online(args[0]));
            if ("list".startsWith(args[0].toLowerCase())) opts.add("list");
            return opts;
        }
        if (args.length == 2) return Tab.filter(List.of("100", "1k", "10k", "100k"), args[1]);
        return List.of();
    }
}
