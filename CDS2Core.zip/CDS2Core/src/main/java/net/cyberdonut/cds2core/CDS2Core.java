package net.cyberdonut.cds2core;

import net.cyberdonut.cds2core.auction.AuctionCommand;
import net.cyberdonut.cds2core.auction.AuctionManager;
import net.cyberdonut.cds2core.bounty.BountyCommand;
import net.cyberdonut.cds2core.bounty.BountyListener;
import net.cyberdonut.cds2core.bounty.BountyManager;
import net.cyberdonut.cds2core.crate.CrateCommand;
import net.cyberdonut.cds2core.crate.CrateListener;
import net.cyberdonut.cds2core.crate.CrateManager;
import net.cyberdonut.cds2core.crate.KeyCommand;
import net.cyberdonut.cds2core.economy.BalCommand;
import net.cyberdonut.cds2core.economy.BaltopCommand;
import net.cyberdonut.cds2core.economy.EcoCommand;
import net.cyberdonut.cds2core.economy.EconomyManager;
import net.cyberdonut.cds2core.economy.PayCommand;
import net.cyberdonut.cds2core.economy.VaultBridge;
import net.cyberdonut.cds2core.gui.MenuListener;
import net.cyberdonut.cds2core.listener.JoinListener;
import net.cyberdonut.cds2core.shop.ShopCommand;
import net.cyberdonut.cds2core.shop.ShopManager;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;

public final class CDS2Core extends JavaPlugin implements TabExecutor, Listener {

    private EconomyManager economy;
    private ShopManager shop;
    private AuctionManager auctions;
    private CrateManager crates;
    private BountyManager bounties;
    private boolean vaultHooked;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveIfMissing("shop.yml");
        saveIfMissing("crates.yml");

        economy = new EconomyManager(this);
        economy.load();
        economy.startAutosave();

        shop = new ShopManager(this);
        shop.load();

        auctions = new AuctionManager(this);
        auctions.load();
        auctions.startTasks();

        crates = new CrateManager(this);
        crates.load();
        crates.startTasks();

        bounties = new BountyManager(this);
        bounties.load();

        register("cds2core", this);
        register("bal", new BalCommand(this));
        register("pay", new PayCommand(this));
        register("baltop", new BaltopCommand(this));
        register("eco", new EcoCommand(this));
        register("shop", new ShopCommand(this));
        register("ah", new AuctionCommand(this));
        register("crate", new CrateCommand(this));
        register("key", new KeyCommand(this));
        register("bounty", new BountyCommand(this));

        var pm = getServer().getPluginManager();
        pm.registerEvents(this, this);
        pm.registerEvents(new MenuListener(), this);
        pm.registerEvents(new JoinListener(this), this);
        pm.registerEvents(new CrateListener(this), this);
        pm.registerEvents(new BountyListener(this), this);

        tryHookVault();

        getComponentLogger().info(Msg.parse("<gradient:#FF5555:#FFAA00>CDS2Core enabled - Cyber Donut SMP 2</gradient>"));
    }

    @Override
    public void onDisable() {
        // Order matters: finish crate animations first (they may deposit money), then flush everything.
        if (crates != null) crates.shutdown();
        if (auctions != null) auctions.save(false);
        if (bounties != null) bounties.save(false);
        if (economy != null) economy.save(false);
    }

    private void register(String name, TabExecutor executor) {
        PluginCommand cmd = getCommand(name);
        if (cmd == null) {
            getLogger().severe("Command '" + name + "' missing from plugin.yml!");
            return;
        }
        cmd.setExecutor(executor);
        cmd.setTabCompleter(executor);
    }

    /** Registers CDS2Core as Vault's economy provider (once). Safe to call when Vault is absent. */
    private void tryHookVault() {
        if (vaultHooked || getServer().getPluginManager().getPlugin("Vault") == null) return;
        VaultBridge.register(this);
        vaultHooked = true;
        getLogger().info("Registered as the Vault economy provider.");
    }

    @EventHandler
    public void onPluginEnable(PluginEnableEvent e) {
        if (e.getPlugin().getName().equals("Vault")) tryHookVault();
    }

    private void saveIfMissing(String resource) {
        if (!new File(getDataFolder(), resource).exists()) saveResource(resource, false);
    }

    // ---- /cds2core reload ----
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            shop.load();
            crates.loadCrates();
            Msg.send(sender, "<green>Configuration, shop and crates reloaded.");
        } else {
            Msg.send(sender, "<red>Usage: <white>/cds2core reload");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return args.length == 1 ? Tab.filter(List.of("reload"), args[0]) : List.of();
    }

    public EconomyManager economy() { return economy; }
    public ShopManager shop() { return shop; }
    public AuctionManager auctions() { return auctions; }
    public CrateManager crates() { return crates; }
    public BountyManager bounties() { return bounties; }
}
