package net.cyberdonut.cds2core.bounty;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.FileIO;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Main-thread only. Bounties stack: placing more on the same target raises the total. */
public final class BountyManager {

    private final CDS2Core plugin;
    private final File file;
    private final Map<UUID, Bounty> bounties = new HashMap<>();

    public BountyManager(CDS2Core plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "bounties.yml");
    }

    public void load() {
        bounties.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yml.getConfigurationSection("bounties");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                long amount = sec.getLong(key + ".amount");
                if (amount > 0) bounties.put(id, new Bounty(id, sec.getString(key + ".name", "Unknown"), amount));
            } catch (IllegalArgumentException ignored) { }
        }
    }

    public void save(boolean async) {
        YamlConfiguration yml = new YamlConfiguration();
        for (Bounty b : bounties.values()) {
            yml.set("bounties." + b.target() + ".name", b.targetName());
            yml.set("bounties." + b.target() + ".amount", b.amountCents());
        }
        String data = yml.saveToString();
        if (async) FileIO.saveAsync(plugin, file, data);
        else FileIO.writeAtomic(file, data);
    }

    public Bounty get(UUID target) { return bounties.get(target); }

    /** Adds to the target's bounty and returns the new total in cents. */
    public long add(UUID target, String name, long cents) {
        long total = cents;
        Bounty old = bounties.get(target);
        if (old != null) total = Math.min(Long.MAX_VALUE / 4, old.amountCents() + cents);
        bounties.put(target, new Bounty(target, name, total));
        save(true);
        return total;
    }

    public Bounty remove(UUID target) {
        Bounty b = bounties.remove(target);
        if (b != null) save(true);
        return b;
    }

    public List<Bounty> top(int limit) {
        List<Bounty> list = new ArrayList<>(bounties.values());
        list.sort(Comparator.comparingLong(Bounty::amountCents).reversed());
        return list.size() > limit ? list.subList(0, limit) : list;
    }
}
