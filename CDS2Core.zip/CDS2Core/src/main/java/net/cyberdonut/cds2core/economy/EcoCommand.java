package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class EcoCommand implements TabExecutor {

    private final CDS2Core plugin;

    public EcoCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length != 3) {
            Msg.send(sender, "<red>Usage: <white>/eco <give|take|set> <player> <amount>");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        EconomyManager eco = plugin.economy();
        UUID id = eco.resolve(args[1]);
        if (id == null || !eco.hasAccount(id)) {
            Msg.send(sender, "<red>No account found for <white><name><red>.", Msg.text("name", args[1]));
            return true;
        }
        long cents = (sub.equals("set") && args[2].equals("0")) ? 0 : EconomyManager.parseAmount(args[2]);
        if (cents < 0) {
            Msg.send(sender, "<red>Invalid amount.");
            return true;
        }
        switch (sub) {
            case "give" -> eco.deposit(id, cents);
            case "take" -> {
                if (!eco.withdraw(id, cents)) {
                    Msg.send(sender, "<red>That player doesn't have enough money.");
                    return true;
                }
            }
            case "set" -> eco.set(id, cents);
            default -> {
                Msg.send(sender, "<red>Usage: <white>/eco <give|take|set> <player> <amount>");
                return true;
            }
        }
        Msg.send(sender, "<green>Done. <white><name><gray>'s balance is now <green><bal><gray>.",
                Msg.text("name", eco.name(id)), Msg.money("bal", eco.getBalance(id)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return Tab.filter(List.of("give", "take", "set"), args[0]);
        if (args.length == 2) return Tab.online(args[1]);
        return List.of();
    }
}
