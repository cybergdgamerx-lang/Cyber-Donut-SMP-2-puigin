package net.cyberdonut.cds2core.crate;

import net.kyori.adventure.text.Component;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public record Reward(String id, double weight, Type type, long moneyCents, ItemStack item,
                     List<String> commands, Component display, ItemStack icon, boolean broadcast) {

    public enum Type { MONEY, ITEM, COMMAND }

    public ItemStack iconCopy() { return icon.clone(); }
}
