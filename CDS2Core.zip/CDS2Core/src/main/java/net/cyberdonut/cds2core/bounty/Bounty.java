package net.cyberdonut.cds2core.bounty;

import java.util.UUID;

public record Bounty(UUID target, String targetName, long amountCents) {}
