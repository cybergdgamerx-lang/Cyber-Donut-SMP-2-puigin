package net.cyberdonut.cds2core.auction;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.FileIO;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** All state is touched on the main thread only; disk writes are handed off asynchronously. */
public final class AuctionManager {

    public enum BuyResult { SUCCESS, GONE, OWN, NO_FUNDS }

    private final CDS2Core plugin;
    private final File file;
    private final Map<UUID, Listing> listings = new LinkedHashMap<>();
    private final Map<UUID, List<ItemStack>> claims = new HashMap<>();

    public AuctionManager(CDS2Core plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auctions.yml");
    }

    // ---------- persistence ----------

    public void load() {
        listings.clear();
        claims.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ls = yml.getConfigurationSection("listings");
        if (ls != null) {
            for (String key : ls.getKeys(false)) {
                try {
                    ConfigurationSection s = ls.getConfigurationSection(key);
                    ItemStack item = decode(s.getString("item"));
                    if (item == null) continue;
                    UUID id = UUID.fromString(key);
                    listings.put(id, new Listing(id, UUID.fromString(s.getString("seller")), s.getString("seller-name", "Unknown"),
                            item, s.getLong("price"), s.getLong("created"), s.getLong("expires")));
                } catch (Exception ex) {
                    plugin.getLogger().warning("Skipping corrupt auction listing " + key);
                }
            }
        }
        ConfigurationSection cs = yml.getConfigurationSection("claims");
        if (cs != null) {
            for (String key : cs.getKeys(false)) {
                try {
                    UUID owner = UUID.fromString(key);
                    List<ItemStack> items = new ArrayList<>();
                    for (String enc : cs.getStringList(key)) {
                        ItemStack it = decode(enc);
                        if (it != null) items.add(it);
                    }
                    if (!items.isEmpty()) claims.put(owner, items);
                } catch (IllegalArgumentException ignored) { }
            }
        }
        plugin.getLogger().info("Loaded " + listings.size() + " auction listings.");
    }

    public void save(boolean async) {
        YamlConfiguration yml = new YamlConfiguration();
        for (Listing l : listings.values()) {
            String p = "listings." + l.id();
            yml.set(p + ".seller", l.seller().toString());
            yml.set(p + ".seller-name", l.sellerName());
            yml.set(p + ".price", l.priceCents());
            yml.set(p + ".created", l.createdAt());
            yml.set(p + ".expires", l.expiresAt());
            yml.set(p + ".item", encode(l.item()));
        }
        for (Map.Entry<UUID, List<ItemStack>> e : claims.entrySet()) {
            List<String> enc = new ArrayList<>();
            for (ItemStack it : e.getValue()) enc.add(encode(it));
            yml.set("claims." + e.getKey(), enc);
        }
        String data = yml.saveToString();
        if (async) FileIO.saveAsync(plugin, file, data);
        else FileIO.writeAtomic(file, data);
    }

    private static String encode(ItemStack item) {
        return Base64.getEncoder().encodeToString(item.serializeAsBytes());
    }

    private static ItemStack decode(String s) {
        if (s == null) return null;
        try {
            return ItemStack.deserializeBytes(Base64.getDecoder().decode(s));
        } catch (Exception ex) {
            return null;
        }
    }

    public void startTasks() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::expireListings, 1200L, 1200L);
    }

    // ---------- queries ----------

    public Listing get(UUID id) { return listings.get(id); }

    public List<Listing> newestFirst() {
        List<Listing> list = new ArrayList<>(listings.values());
        list.sort(Comparator.comparingLong(Listing::createdAt).reversed());
        return list;
    }

    public int countBy(UUID seller) {
        int n = 0;
        for (Listing l : listings.values()) if (l.seller().equals(seller)) n++;
        return n;
    }

    public int pendingClaims(UUID owner) {
        List<ItemStack> list = claims.get(owner);
        return list == null ? 0 : list.size();
    }

    // ---------- config ----------

    public int maxListings() { return plugin.getConfig().getInt("auction.max-listings-per-player", 10); }
    public long minPriceCents() { return Math.max(1L, Math.round(plugin.getConfig().getDouble("auction.min-price", 1.0) * 100)); }
    public long maxPriceCents() { return Math.round(plugin.getConfig().getDouble("auction.max-price", 1_000_000_000_000.0) * 100); }
    private long durationMs() { return plugin.getConfig().getLong("auction.duration-hours", 48) * 3_600_000L; }
    private double taxPercent() { return Math.max(0, Math.min(100, plugin.getConfig().getDouble("auction.tax-percent", 5.0))); }

    // ---------- actions ----------

    public Listing list(Player seller, ItemStack item, long priceCents) {
        long now = System.currentTimeMillis();
        Listing l = new Listing(UUID.randomUUID(), seller.getUniqueId(), seller.getName(), item.clone(), priceCents, now, now + durationMs());
        listings.put(l.id(), l);
        save(true);
        return l;
    }

    public BuyResult buy(Player buyer, UUID listingId) {
        Listing l = listings.get(listingId);
        if (l == null) return BuyResult.GONE;
        if (l.seller().equals(buyer.getUniqueId())) return BuyResult.OWN;
        if (!plugin.economy().withdraw(buyer.getUniqueId(), l.priceCents())) return BuyResult.NO_FUNDS;
        if (listings.remove(listingId) == null) { // defensive: never charge for a listing that vanished
            plugin.economy().deposit(buyer.getUniqueId(), l.priceCents());
            return BuyResult.GONE;
        }
        long tax = (long) Math.floor(l.priceCents() * (taxPercent() / 100.0));
        plugin.economy().deposit(l.seller(), l.priceCents() - tax);
        giveOrDrop(buyer, l.item().clone());
        save(true);

        Player seller = Bukkit.getPlayer(l.seller());
        if (seller != null) {
            Msg.send(seller, "<white><buyer> <gray>bought your <item> <gray>for <green><price><gray>.",
                    Msg.text("buyer", buyer.getName()),
                    Placeholder.component("item", l.item().displayName()),
                    Msg.money("price", l.priceCents() - tax));
            seller.playSound(seller.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
        }
        return BuyResult.SUCCESS;
    }

    /** Seller cancels their own listing; item returns to them (or to their claim box if inventory is full). */
    public boolean cancel(Player player, Listing l) {
        if (!l.seller().equals(player.getUniqueId())) return false;
        if (listings.remove(l.id()) == null) return false;
        var left = player.getInventory().addItem(l.item().clone());
        left.values().forEach(it -> claims.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>()).add(it));
        save(true);
        return true;
    }

    /** Gives back items from expired listings. Anything that doesn't fit stays claimable. */
    public void claim(Player player) {
        List<ItemStack> list = claims.get(player.getUniqueId());
        if (list == null || list.isEmpty()) {
            Msg.send(player, "<gray>You have nothing to claim.");
            return;
        }
        List<ItemStack> remaining = new ArrayList<>();
        int given = 0;
        for (ItemStack it : list) {
            var left = player.getInventory().addItem(it);
            if (left.isEmpty()) given++; else remaining.addAll(left.values());
        }
        if (remaining.isEmpty()) claims.remove(player.getUniqueId());
        else claims.put(player.getUniqueId(), remaining);
        save(true);
        Msg.send(player, "<green>Claimed <white><n> <green>item stack(s).<rest>",
                Placeholder.unparsed("n", String.valueOf(given)),
                Placeholder.parsed("rest", remaining.isEmpty() ? "" : " <yellow>Some items didn't fit - free up space and claim again."));
    }

    private void giveOrDrop(Player p, ItemStack item) {
        var left = p.getInventory().addItem(item);
        left.values().forEach(it -> p.getWorld().dropItemNaturally(p.getLocation(), it));
    }

    private void expireListings() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        Iterator<Listing> it = listings.values().iterator();
        while (it.hasNext()) {
            Listing l = it.next();
            if (l.expiresAt() > now) continue;
            it.remove();
            claims.computeIfAbsent(l.seller(), k -> new ArrayList<>()).add(l.item());
            changed = true;
            Player seller = Bukkit.getPlayer(l.seller());
            if (seller != null) Msg.send(seller, "<yellow>One of your auction listings expired. Use <white>/ah claim <yellow>to get the item back.");
        }
        if (changed) save(true);
    }
}
