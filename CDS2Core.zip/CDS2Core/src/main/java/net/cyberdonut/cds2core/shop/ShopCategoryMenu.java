package net.cyberdonut.cds2core.shop;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.gui.CDSMenu;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Left = buy 1, Shift+Left = buy 64, Right = sell 1, Shift+Right = sell all.
 * All transactions are atomic on the main thread: money moves first, items second,
 * and any item that does not fit is refunded - so nothing can be duplicated.
 */
public final class ShopCategoryMenu extends CDSMenu {

    private static final int BACK = 49, BALANCE = 53;
    private final ShopCategory category;

    public ShopCategoryMenu(CDS2Core plugin, Player viewer, ShopCategory category) {
        super(plugin);
        this.category = category;
        init(54, Msg.parse(category.display()));
        render(viewer);
    }

    private void render(Player viewer) {
        getInventory().clear();
        List<ShopItem> items = category.items();
        for (int i = 0; i < items.size() && i < 45; i++) {
            ShopItem it = items.get(i);
            List<Component> lore = new ArrayList<>();
            lore.add(Msg.noItalic("<dark_gray>―――――――――――"));
            if (it.canBuy()) {
                lore.add(Msg.noItalic("<green>Buy: <white><p>", Msg.money("p", it.buyCents())));
                lore.add(Msg.noItalic("<gray>Left-click <dark_gray>x1 <gray>| Shift <dark_gray>x64"));
            } else {
                lore.add(Msg.noItalic("<red>Not for sale"));
            }
            if (it.canSell()) {
                lore.add(Msg.noItalic("<gold>Sell: <white><p>", Msg.money("p", it.sellCents())));
                lore.add(Msg.noItalic("<gray>Right-click <dark_gray>x1 <gray>| Shift <dark_gray>all"));
            }
            getInventory().setItem(i, new ItemBuilder(it.material()).lore(lore).build());
        }
        getInventory().setItem(BACK, new ItemBuilder(Material.ARROW).name("<yellow>« Back").build());
        getInventory().setItem(BALANCE, new ItemBuilder(Material.GOLD_INGOT)
                .name("<gold>Your Balance")
                .lore("<green><bal>", Msg.money("bal", plugin.economy().getBalance(viewer.getUniqueId())))
                .build());
        fillEmpty();
    }

    @Override
    public void onClick(Player p, InventoryClickEvent e) {
        int slot = e.getSlot();
        if (slot == BACK) {
            new ShopMenu(plugin, p).open(p);
            return;
        }
        if (slot < 0 || slot >= category.items().size() || slot >= 45) return;
        ShopItem it = category.items().get(slot);
        switch (e.getClick()) {
            case LEFT -> buy(p, it, 1);
            case SHIFT_LEFT -> buy(p, it, 64);
            case RIGHT -> sell(p, it, false);
            case SHIFT_RIGHT -> sell(p, it, true);
            default -> { return; }
        }
        render(p);
    }

    private void buy(Player p, ShopItem it, int qty) {
        if (!it.canBuy()) {
            Msg.send(p, "<red>This item can't be bought.");
            return;
        }
        UUID id = p.getUniqueId();
        long unit = it.buyCents();
        long total = unit * qty;
        if (!plugin.economy().withdraw(id, total)) {
            Msg.send(p, "<red>You need <white><cost> <red>to buy that.", Msg.money("cost", total));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1f);
            return;
        }
        Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(it.material(), qty));
        int leftover = left.values().stream().mapToInt(ItemStack::getAmount).sum();
        if (leftover > 0) plugin.economy().deposit(id, unit * leftover); // refund what didn't fit
        int bought = qty - leftover;
        if (bought <= 0) {
            Msg.send(p, "<red>Your inventory is full.");
            return;
        }
        Msg.send(p, "<gray>Bought <white><n>x <item> <gray>for <green><cost><gray>.",
                Placeholder.unparsed("n", String.valueOf(bought)),
                Placeholder.component("item", Component.translatable(it.material().translationKey())),
                Msg.money("cost", unit * bought));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.4f);
    }

    private void sell(Player p, ShopItem it, boolean all) {
        if (!it.canSell()) {
            Msg.send(p, "<red>This item can't be sold.");
            return;
        }
        PlayerInventory inv = p.getInventory();
        int have = countPlain(inv, it.material());
        if (have <= 0) {
            Msg.send(p, "<red>You don't have any plain <item><red> to sell.",
                    Placeholder.component("item", Component.translatable(it.material().translationKey())));
            return;
        }
        int want = all ? have : 1;
        int removed = removePlain(inv, it.material(), want);
        if (removed <= 0) return;
        long total = it.sellCents() * removed;
        plugin.economy().deposit(p.getUniqueId(), total);
        p.updateInventory();
        Msg.send(p, "<gray>Sold <white><n>x <item> <gray>for <green><cost><gray>.",
                Placeholder.unparsed("n", String.valueOf(removed)),
                Placeholder.component("item", Component.translatable(it.material().translationKey())),
                Msg.money("cost", total));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 0.9f);
    }

    /** Only vanilla-plain stacks count: no custom names, enchants, or damage. */
    private static int countPlain(PlayerInventory inv, Material mat) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s != null && s.getType() == mat && !s.hasItemMeta()) n += s.getAmount();
        }
        return n;
    }

    private static int removePlain(PlayerInventory inv, Material mat, int amount) {
        int remaining = amount;
        for (int i = 0; i < 36 && remaining > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || s.getType() != mat || s.hasItemMeta()) continue;
            int take = Math.min(remaining, s.getAmount());
            if (take >= s.getAmount()) {
                inv.setItem(i, null);
            } else {
                ItemStack copy = s.clone();
                copy.setAmount(s.getAmount() - take);
                inv.setItem(i, copy);
            }
            remaining -= take;
        }
        return amount - remaining;
    }
}
