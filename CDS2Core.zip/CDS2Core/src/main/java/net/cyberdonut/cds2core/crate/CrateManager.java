package net.cyberdonut.cds2core.crate;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.FileIO;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class CrateManager {

    public record BlockKey(UUID world, int x, int y, int z) {
        public static BlockKey of(Block b) { return new BlockKey(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()); }
    }

    private final CDS2Core plugin;
    private final File blocksFile;
    private final NamespacedKey keyTag;
    private final Map<String, Crate> crates = new LinkedHashMap<>();
    private final Map<BlockKey, String> blocks = new HashMap<>();
    private final Map<UUID, CrateOpenMenu> active = new HashMap<>();

    public CrateManager(CDS2Core plugin) {
        this.plugin = plugin;
        this.blocksFile = new File(plugin.getDataFolder(), "crate-blocks.yml");
        this.keyTag = new NamespacedKey(plugin, "crate_key");
    }

    // ---------- loading / saving ----------

    public void load() {
        loadCrates();
        blocks.clear();
        if (!blocksFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(blocksFile);
        for (String line : yml.getStringList("blocks")) {
            String[] p = line.split(";");
            if (p.length != 5) continue;
            try {
                blocks.put(new BlockKey(UUID.fromString(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])), p[4]);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    public void saveBlocks(boolean async) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<BlockKey, String> e : blocks.entrySet()) {
            BlockKey k = e.getKey();
            out.add(k.world() + ";" + k.x() + ";" + k.y() + ";" + k.z() + ";" + e.getValue());
        }
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("blocks", out);
        String data = yml.saveToString();
        if (async) FileIO.saveAsync(plugin, blocksFile, data);
        else FileIO.writeAtomic(blocksFile, data);
    }

    public void loadCrates() {
        crates.clear();
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "crates.yml"));
        ConfigurationSection cs = yml.getConfigurationSection("crates");
        if (cs == null) return;
        for (String id : cs.getKeys(false)) {
            ConfigurationSection s = cs.getConfigurationSection(id);
            if (s == null) continue;
            String cid = id.toLowerCase(Locale.ROOT);
            List<Reward> rewards = new ArrayList<>();
            double total = 0;
            ConfigurationSection rs = s.getConfigurationSection("rewards");
            if (rs != null) {
                for (String rid : rs.getKeys(false)) {
                    ConfigurationSection r = rs.getConfigurationSection(rid);
                    Reward reward = r == null ? null : parseReward(cid, rid, r);
                    if (reward != null) { rewards.add(reward); total += reward.weight(); }
                }
            }
            if (rewards.isEmpty()) {
                plugin.getLogger().warning("Crate '" + cid + "' has no valid rewards and was skipped.");
                continue;
            }
            Material keyMat = Material.matchMaterial(s.getString("key-material", "TRIPWIRE_HOOK"));
            if (keyMat == null || !keyMat.isItem()) keyMat = Material.TRIPWIRE_HOOK;
            String display = s.getString("display", cid);
            crates.put(cid, new Crate(cid, display, keyMat, s.getString("key-name", display + " <white>Key"), List.copyOf(rewards), total));
        }
        plugin.getLogger().info("Loaded " + crates.size() + " crates.");
    }

    private Reward parseReward(String crateId, String id, ConfigurationSection s) {
        double weight = s.getDouble("weight", 1);
        if (weight <= 0) return null;
        Reward.Type type;
        try {
            type = Reward.Type.valueOf(s.getString("type", "ITEM").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("crates.yml: bad reward type in " + crateId + "." + id);
            return null;
        }
        boolean broadcast = s.getBoolean("broadcast", false);

        switch (type) {
            case MONEY -> {
                long cents = Math.round(s.getDouble("amount") * 100.0);
                if (cents <= 0) return null;
                Component display = Msg.noItalic(s.getString("display", "<green>" + Msg.money(cents)));
                Material mat = mat(s.getString("icon"), Material.GOLD_INGOT);
                return new Reward(id, weight, type, cents, null, List.of(), display, new ItemBuilder(mat).name(display).build(), broadcast);
            }
            case COMMAND -> {
                List<String> cmds = s.getStringList("commands");
                if (cmds.isEmpty()) return null;
                Component display = Msg.noItalic(s.getString("display", id));
                Material mat = mat(s.getString("icon"), Material.PAPER);
                return new Reward(id, weight, type, 0, null, List.copyOf(cmds), display, new ItemBuilder(mat).name(display).build(), broadcast);
            }
            default -> {
                Material mat = Material.matchMaterial(s.getString("material", ""));
                if (mat == null || !mat.isItem() || mat.isAir()) {
                    plugin.getLogger().warning("crates.yml: bad material in " + crateId + "." + id);
                    return null;
                }
                ItemStack item = new ItemStack(mat, Math.max(1, Math.min(mat.getMaxStackSize(), s.getInt("amount", 1))));
                ItemMeta meta = item.getItemMeta();
                String name = s.getString("name");
                if (name != null) meta.displayName(Msg.noItalic(name));
                List<String> lore = s.getStringList("lore");
                if (!lore.isEmpty()) {
                    List<Component> lines = new ArrayList<>();
                    for (String l : lore) lines.add(Msg.noItalic(l));
                    meta.lore(lines);
                }
                ConfigurationSection en = s.getConfigurationSection("enchants");
                if (en != null) {
                    for (String ek : en.getKeys(false)) {
                        Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(ek.toLowerCase(Locale.ROOT)));
                        if (ench == null) {
                            plugin.getLogger().warning("crates.yml: unknown enchant '" + ek + "' in " + crateId + "." + id);
                            continue;
                        }
                        int lvl = Math.max(1, en.getInt(ek));
                        if (meta instanceof EnchantmentStorageMeta esm) esm.addStoredEnchant(ench, lvl, true);
                        else meta.addEnchant(ench, lvl, true);
                    }
                }
                if (s.getBoolean("glow")) meta.setEnchantmentGlintOverride(true);
                item.setItemMeta(meta);
                Component display = name != null ? Msg.noItalic(name) : Component.translatable(mat.translationKey());
                return new Reward(id, weight, type, 0, item, List.of(), display, item.clone(), broadcast);
            }
        }
    }

    private static Material mat(String name, Material fallback) {
        if (name == null) return fallback;
        Material m = Material.matchMaterial(name);
        return m == null || !m.isItem() ? fallback : m;
    }

    public void startTasks() {
        if (!plugin.getConfig().getBoolean("crates.particles", true)) return;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (BlockKey k : blocks.keySet()) {
                World w = Bukkit.getWorld(k.world());
                if (w == null || !w.isChunkLoaded(k.x() >> 4, k.z() >> 4)) continue;
                w.spawnParticle(Particle.ENCHANT, k.x() + 0.5, k.y() + 1.2, k.z() + 0.5, 6, 0.3, 0.3, 0.3, 0.5);
            }
        }, 20L, 10L);
    }

    /** Finish every running animation so nobody loses a consumed key on shutdown. */
    public void shutdown() {
        for (CrateOpenMenu menu : new ArrayList<>(active.values())) menu.finish();
        saveBlocks(false);
    }

    // ---------- crate types ----------

    public Crate getCrate(String id) { return id == null ? null : crates.get(id.toLowerCase(Locale.ROOT)); }
    public Collection<Crate> allCrates() { return crates.values(); }
    public List<String> crateIds() { return new ArrayList<>(crates.keySet()); }

    // ---------- crate blocks ----------

    public Crate getCrateAt(Block b) {
        String id = blocks.get(BlockKey.of(b));
        return id == null ? null : crates.get(id);
    }

    public boolean isCrateBlock(Block b) { return blocks.containsKey(BlockKey.of(b)); }

    public void setCrateBlock(Block b, Crate crate) {
        blocks.put(BlockKey.of(b), crate.id());
        saveBlocks(true);
    }

    public boolean removeCrateBlock(Block b) {
        boolean removed = blocks.remove(BlockKey.of(b)) != null;
        if (removed) saveBlocks(true);
        return removed;
    }

    public int blockCount(String crateId) {
        int n = 0;
        for (String id : blocks.values()) if (id.equals(crateId)) n++;
        return n;
    }

    // ---------- keys ----------

    public ItemStack createKey(Crate crate, int amount) {
        return new ItemBuilder(crate.keyMaterial())
                .amount(amount)
                .name(crate.keyName())
                .lore("<gray>Right-click a " + crate.display() + "<gray> to open it.")
                .lore("<dark_gray>Cyber Donut SMP 2")
                .glow(true)
                .pdc(keyTag, crate.id())
                .build();
    }

    /** Returns the crate id stored in the item's persistent data, or null if it isn't a CDS2 key. */
    public String getKeyCrateId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(keyTag, PersistentDataType.STRING);
    }

    public void giveKeys(Player p, Crate crate, int amount) {
        int remaining = amount;
        while (remaining > 0) {
            int n = Math.min(64, remaining);
            p.getInventory().addItem(createKey(crate, n)).values()
                    .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
            remaining -= n;
        }
    }

    // ---------- opening ----------

    public boolean isOpening(UUID id) { return active.containsKey(id); }
    void register(UUID id, CrateOpenMenu menu) { active.put(id, menu); }
    void unregister(UUID id, CrateOpenMenu menu) { active.remove(id, menu); }

    public void open(Player p, Crate crate) {
        CrateOpenMenu menu = new CrateOpenMenu(plugin, p, crate);
        register(p.getUniqueId(), menu);
        menu.start();
    }

    public void give(Player p, Reward r) {
        switch (r.type()) {
            case MONEY -> plugin.economy().deposit(p.getUniqueId(), r.moneyCents());
            case ITEM -> p.getInventory().addItem(r.item().clone()).values()
                    .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
            case COMMAND -> {
                for (String cmd : r.commands()) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
                }
            }
        }
    }
}
