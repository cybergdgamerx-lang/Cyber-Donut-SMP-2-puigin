package net.cyberdonut.cds2core.crate;

import org.bukkit.Material;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public record Crate(String id, String display, Material keyMaterial, String keyName, List<Reward> rewards, double totalWeight) {

    /** Weighted random pick. The result is decided here, server-side, before any animation plays. */
    public Reward roll() {
        double r = ThreadLocalRandom.current().nextDouble() * totalWeight;
        double acc = 0;
        for (Reward rw : rewards) {
            acc += rw.weight();
            if (r < acc) return rw;
        }
        return rewards.get(rewards.size() - 1);
    }
}
