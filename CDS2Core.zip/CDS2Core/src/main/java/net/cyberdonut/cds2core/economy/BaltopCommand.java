package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Sorting happens off the main thread; only the final send is scheduled back. */
public final class BaltopCommand implements TabExecutor {

    private static final long COOLDOWN_MS = 3000L;
    private final CDS2Core plugin;
    private final Map<UUID, Long> lastUse = new HashMap<>(); // main thread only

    public BaltopCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player p) {
            long now = System.currentTimeMillis();
            Long last = lastUse.get(p.getUniqueId());
            if (last != null && now - last < COOLDOWN_MS) {
                Msg.send(p, "<red>Please wait a moment before using /baltop again.");
                return true;
            }
            lastUse.put(p.getUniqueId(), now);
        }
        UUID requester = sender instanceof Player p ? p.getUniqueId() : null;
        int size = 10;
        EconomyManager eco = plugin.economy();

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<Map.Entry<UUID, Long>> top = eco.top(size);
            List<Component> lines = new ArrayList<>();
            lines.add(Msg.parse("<gradient:#FF5555:#FFAA00><bold>══ Richest Players ══</bold></gradient>"));
            int rank = 1;
            for (Map.Entry<UUID, Long> e : top) {
                String color = switch (rank) { case 1 -> "<#FFD700>"; case 2 -> "<#C0C0C0>"; case 3 -> "<#CD7F32>"; default -> "<gray>"; };
                lines.add(Msg.parse(color + "#<rank> <white><name> <dark_gray>- <green><bal>",
                        Placeholder.unparsed("rank", String.valueOf(rank)),
                        Placeholder.unparsed("name", eco.name(e.getKey())),
                        Msg.money("bal", e.getValue())));
                rank++;
            }
            if (requester != null) {
                lines.add(Msg.parse("<dark_gray>Your rank: <yellow>#<rank>", Placeholder.unparsed("rank", String.valueOf(eco.rank(requester)))));
            }
            Bukkit.getScheduler().runTask(plugin, () -> lines.forEach(sender::sendMessage));
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return List.of();
    }
}
