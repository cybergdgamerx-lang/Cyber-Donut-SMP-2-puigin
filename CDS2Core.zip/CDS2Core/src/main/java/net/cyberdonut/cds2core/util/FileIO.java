package net.cyberdonut.cds2core.util;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/** Crash-safe file writes: write to temp file, then atomically move over the target. */
public final class FileIO {

    private static final Map<Path, Object> LOCKS = new ConcurrentHashMap<>();

    private FileIO() {}

    public static void writeAtomic(File file, String content) {
        Path target = file.toPath();
        Object lock = LOCKS.computeIfAbsent(target, k -> new Object());
        synchronized (lock) {
            try {
                Path parent = target.getParent();
                if (parent != null) Files.createDirectories(parent);
                Path tmp = target.resolveSibling(file.getName() + ".tmp");
                Files.writeString(tmp, content, StandardCharsets.UTF_8);
                try {
                    Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                } catch (AtomicMoveNotSupportedException ex) {
                    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException ex) {
                Bukkit.getLogger().log(Level.SEVERE, "[CDS2Core] Failed to save " + file.getName(), ex);
            }
        }
    }

    public static void saveAsync(Plugin plugin, File file, String content) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> writeAtomic(file, content));
    }
}
