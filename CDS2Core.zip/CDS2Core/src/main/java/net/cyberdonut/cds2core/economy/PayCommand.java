package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public final class PayCommand implements TabExecutor {

    private final CDS2Core plugin;

    public PayCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "<red>Only players can use /pay.");
            return true;
        }
        if (args.length != 2) {
            Msg.send(p, "<red>Usage: <white>/pay <player> <amount>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            Msg.send(p, "<red>That player is not online.");
            return true;
        }
        if (target.getUniqueId().equals(p.getUniqueId())) {
            Msg.send(p, "<red>You can't pay yourself.");
            return true;
        }
        long cents = EconomyManager.parseAmount(args[1]);
        if (cents <= 0) {
            Msg.send(p, "<red>Invalid amount. Use a positive number (e.g. <white>500<red>, <white>2.5k<red>, <white>1m<red>).");
            return true;
        }
        if (!plugin.economy().transfer(p.getUniqueId(), target.getUniqueId(), cents)) {
            Msg.send(p, "<red>You don't have enough money. Balance: <white><bal>", Msg.money("bal", plugin.economy().getBalance(p.getUniqueId())));
            return true;
        }
        Msg.send(p, "<gray>You paid <white><name> <gradient:#55FF55:#FFFF55><amt></gradient><gray>.",
                Msg.text("name", target.getName()), Msg.money("amt", cents));
        Msg.send(target, "<white><name> <gray>sent you <gradient:#55FF55:#FFFF55><amt></gradient><gray>.",
                Msg.text("name", p.getName()), Msg.money("amt", cents));
        target.playSound(target.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return Tab.online(args[0]);
        if (args.length == 2) return Tab.filter(List.of("100", "1k", "10k", "100k", "1m"), args[1]);
        return List.of();
    }
}
