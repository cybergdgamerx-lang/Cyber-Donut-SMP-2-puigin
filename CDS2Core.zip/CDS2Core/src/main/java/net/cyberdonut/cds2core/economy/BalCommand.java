package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

public final class BalCommand implements TabExecutor {

    private final CDS2Core plugin;

    public BalCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        EconomyManager eco = plugin.economy();
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                Msg.send(sender, "<red>Console usage: /bal <player>");
                return true;
            }
            Msg.send(p, "<gray>Your balance: <gradient:#55FF55:#FFFF55><bal></gradient>", Msg.money("bal", eco.getBalance(p.getUniqueId())));
            return true;
        }
        if (!sender.hasPermission("cds2.economy.balance.others")) {
            Msg.send(sender, "<red>You can't view other players' balances.");
            return true;
        }
        UUID id = eco.resolve(args[0]);
        if (id == null || !eco.hasAccount(id)) {
            Msg.send(sender, "<red>No account found for <white><name><red>.", Msg.text("name", args[0]));
            return true;
        }
        Msg.send(sender, "<white><name><gray>'s balance: <gradient:#55FF55:#FFFF55><bal></gradient>",
                Msg.text("name", eco.name(id)), Msg.money("bal", eco.getBalance(id)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return args.length == 1 ? Tab.online(args[0]) : List.of();
    }
}
