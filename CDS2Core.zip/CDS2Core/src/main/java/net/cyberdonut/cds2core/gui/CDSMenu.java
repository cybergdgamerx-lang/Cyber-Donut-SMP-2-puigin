package net.cyberdonut.cds2core.gui;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/**
 * Base class for every CDS2 GUI. The inventory's holder is the menu itself, so
 * {@link MenuListener} can identify our inventories without comparing titles.
 * ALL clicks/drags in a CDS menu are cancelled before reaching onClick, which
 * removes the classic GUI dupe vectors (shift-click, number keys, offhand swap,
 * double-click collect, drag).
 */
public abstract class CDSMenu implements InventoryHolder {

    protected final CDS2Core plugin;
    private Inventory inventory;

    protected CDSMenu(CDS2Core plugin) {
        this.plugin = plugin;
    }

    protected final void init(int size, Component title) {
        this.inventory = Bukkit.createInventory(this, size, title);
    }

    protected static ItemStack filler() {
        return new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name("<dark_gray> ").build();
    }

    protected final void fillEmpty() {
        ItemStack f = filler();
        for (int i = 0; i < inventory.getSize(); i++) {
            if (inventory.getItem(i) == null) inventory.setItem(i, f);
        }
    }

    /** Called only for clicks inside this menu's top inventory. The event is already cancelled. */
    public abstract void onClick(Player player, InventoryClickEvent event);

    public void onClose(Player player) {}

    public void open(Player player) {
        player.openInventory(inventory);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
