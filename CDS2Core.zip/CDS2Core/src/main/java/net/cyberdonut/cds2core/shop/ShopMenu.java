package net.cyberdonut.cds2core.shop;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.gui.CDSMenu;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.cyberdonut.cds2core.util.Msg;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.HashMap;
import java.util.Map;

public final class ShopMenu extends CDSMenu {

    private final Map<Integer, ShopCategory> slots = new HashMap<>();

    public ShopMenu(CDS2Core plugin, Player viewer) {
        super(plugin);
        init(27, Msg.parse("<gradient:#FF5555:#FFAA00><bold>CDS2 Shop</bold></gradient>"));
        for (ShopCategory c : plugin.shop().categories()) {
            if (c.slot() < 0 || c.slot() >= 27 || c.slot() == 22) continue;
            getInventory().setItem(c.slot(), new ItemBuilder(c.icon())
                    .name(c.display())
                    .lore("<gray>" + c.items().size() + " items")
                    .lore("<yellow>Click to browse")
                    .build());
            slots.put(c.slot(), c);
        }
        getInventory().setItem(22, new ItemBuilder(Material.GOLD_INGOT)
                .name("<gold>Your Balance")
                .lore("<green><bal>", Msg.money("bal", plugin.economy().getBalance(viewer.getUniqueId())))
                .build());
        fillEmpty();
    }

    @Override
    public void onClick(Player player, InventoryClickEvent e) {
        ShopCategory c = slots.get(e.getSlot());
        if (c == null) return;
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        new ShopCategoryMenu(plugin, player, c).open(player);
    }
}
