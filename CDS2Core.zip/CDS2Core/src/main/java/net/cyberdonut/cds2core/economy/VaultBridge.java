package net.cyberdonut.cds2core.economy;

import net.cyberdonut.cds2core.CDS2Core;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.ServicePriority;

/** Loaded only when Vault is present (see CDS2Core#tryHookVault). */
public final class VaultBridge {
    private VaultBridge() {}

    public static void register(CDS2Core plugin) {
        plugin.getServer().getServicesManager().register(
                Economy.class, new VaultEconomyProvider(plugin), plugin, ServicePriority.Highest);
    }
}
