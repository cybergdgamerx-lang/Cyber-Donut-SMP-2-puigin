package net.cyberdonut.cds2core.auction;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.economy.EconomyManager;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;

public final class AuctionCommand implements TabExecutor {

    private final CDS2Core plugin;

    public AuctionCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            Msg.send(sender, "<red>Only players can use the auction house.");
            return true;
        }
        if (args.length == 0) {
            new AuctionMenu(plugin, p, 0).open(p);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "sell" -> sell(p, args);
            case "claim" -> plugin.auctions().claim(p);
            default -> Msg.send(p, "<red>Usage: <white>/ah <gray>| <white>/ah sell <price> <gray>| <white>/ah claim");
        }
        return true;
    }

    private void sell(Player p, String[] args) {
        if (!p.hasPermission("cds2.ah.sell")) {
            Msg.send(p, "<red>You can't list items.");
            return;
        }
        if (args.length != 2) {
            Msg.send(p, "<red>Usage: <white>/ah sell <price>");
            return;
        }
        AuctionManager ah = plugin.auctions();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR || hand.getAmount() <= 0) {
            Msg.send(p, "<red>Hold the item you want to sell in your main hand.");
            return;
        }
        long price = EconomyManager.parseAmount(args[1]);
        if (price <= 0) {
            Msg.send(p, "<red>Invalid price.");
            return;
        }
        if (price < ah.minPriceCents() || price > ah.maxPriceCents()) {
            Msg.send(p, "<red>Price must be between <white><min> <red>and <white><max><red>.",
                    Msg.money("min", ah.minPriceCents()), Msg.money("max", ah.maxPriceCents()));
            return;
        }
        if (ah.countBy(p.getUniqueId()) >= ah.maxListings()) {
            Msg.send(p, "<red>You already have <white><n> <red>active listings.", Placeholder.unparsed("n", String.valueOf(ah.maxListings())));
            return;
        }
        ItemStack listed = hand.clone();
        p.getInventory().setItemInMainHand(null); // remove first, list second: a failed call can never dupe
        ah.list(p, listed, price);
        Msg.send(p, "<green>Listed <item> <green>for <white><price><green>.",
                Placeholder.component("item", listed.displayName()), Msg.money("price", price));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return Tab.filter(List.of("sell", "claim"), args[0]);
        if (args.length == 2 && args[0].equalsIgnoreCase("sell")) return Tab.filter(List.of("100", "1k", "10k", "100k"), args[1]);
        return List.of();
    }
}
