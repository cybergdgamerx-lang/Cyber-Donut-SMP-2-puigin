package net.cyberdonut.cds2core.crate;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.gui.CDSMenu;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Roulette animation. The winner is rolled BEFORE the animation starts and is placed in the
 * centre slot of the final frame, so closing the GUI, lag or a crash mid-animation cannot
 * change the outcome. Closing early simply completes the opening instantly.
 */
public final class CrateOpenMenu extends CDSMenu {

    private static final int STEPS = 36;
    private static final int CENTER = 13;
    private static final Material[] PANES = {
            Material.CYAN_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE,
            Material.ORANGE_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE, Material.RED_STAINED_GLASS_PANE
    };

    private final Player player;
    private final Crate crate;
    private final Reward winner;
    private final List<Reward> strip = new ArrayList<>();
    private int step;
    private boolean finished;
    private BukkitTask task;

    public CrateOpenMenu(CDS2Core plugin, Player player, Crate crate) {
        super(plugin);
        this.player = player;
        this.crate = crate;
        this.winner = crate.roll();
        init(27, Msg.parse(crate.display() + " <dark_gray>- <gray>Opening..."));
        for (int i = 0; i < STEPS + 9; i++) strip.add(crate.roll());
        strip.set(STEPS + 4, winner); // centre of the final window
        render();
    }

    public void start() {
        open(player);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1f, 1f);
        task = Bukkit.getScheduler().runTaskLater(plugin, this::tick, 4L);
    }

    private void tick() {
        if (finished) return;
        step++;
        render();
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.6f, 0.8f + step * 0.02f);
        if (step >= STEPS) {
            task = Bukkit.getScheduler().runTaskLater(plugin, this::finish, 10L);
        } else {
            long delay = step < 18 ? 2L : step < 26 ? 3L : step < 31 ? 5L : 8L;
            task = Bukkit.getScheduler().runTaskLater(plugin, this::tick, delay);
        }
    }

    private void render() {
        for (int i = 0; i < 27; i++) {
            if (i >= 9 && i <= 17) continue;
            getInventory().setItem(i, new ItemBuilder(PANES[(i + step) % PANES.length]).name("<dark_gray> ").build());
        }
        getInventory().setItem(4, new ItemBuilder(Material.HOPPER).name("<yellow>▼").build());
        getInventory().setItem(22, new ItemBuilder(Material.HOPPER).name("<yellow>▲").build());
        for (int i = 0; i < 9; i++) {
            ItemStack icon = strip.get(step + i).iconCopy();
            getInventory().setItem(9 + i, icon);
        }
    }

    /** Idempotent. Safe to call from the timer, from onClose, or from plugin shutdown. */
    public void finish() {
        if (finished) return;
        finished = true;
        if (task != null) task.cancel();
        step = STEPS;
        render();
        plugin.crates().give(player, winner);
        plugin.crates().unregister(player.getUniqueId(), this);

        Msg.send(player, "<gray>You won <reward><gray>!", Placeholder.component("reward", winner.display()));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        if (winner.broadcast()) {
            Msg.broadcast("<white><player> <gray>opened a <crate> <gray>and won <reward><gray>!",
                    Msg.text("player", player.getName()),
                    Placeholder.parsed("crate", crate.display()),
                    Placeholder.component("reward", winner.display()));
        }
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTaskLater(plugin, this::closeIfOpen, 40L);
        } else {
            closeIfOpen();
        }
    }

    private void closeIfOpen() {
        if (player.isOnline() && player.getOpenInventory().getTopInventory().getHolder(false) == this) {
            player.closeInventory();
        }
    }

    @Override
    public void onClick(Player player, InventoryClickEvent event) { /* display only */ }

    @Override
    public void onClose(Player player) {
        finish(); // closing early never forfeits the key - the reward is delivered immediately
    }
}
