package net.cyberdonut.cds2core.auction;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.gui.CDSMenu;
import net.cyberdonut.cds2core.util.ItemBuilder;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class AuctionMenu extends CDSMenu {

    private static final int PER_PAGE = 45, PREV = 45, CLAIM = 47, INFO = 49, NEXT = 53;
    private final Map<Integer, UUID> slotToListing = new HashMap<>();
    private int page;
    private UUID pending;
    private long pendingUntil;

    public AuctionMenu(CDS2Core plugin, Player viewer, int page) {
        super(plugin);
        this.page = page;
        init(54, Msg.parse("<gradient:#FF5555:#FFAA00><bold>Auction House</bold></gradient>"));
        render(viewer);
    }

    private int maxPage(int total) { return Math.max(0, (total - 1) / PER_PAGE); }

    private void render(Player viewer) {
        getInventory().clear();
        slotToListing.clear();
        List<Listing> all = plugin.auctions().newestFirst();
        page = Math.max(0, Math.min(page, maxPage(all.size())));
        long now = System.currentTimeMillis();

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= all.size()) break;
            Listing l = all.get(idx);
            boolean mine = l.seller().equals(viewer.getUniqueId());
            List<Component> extra = new ArrayList<>();
            extra.add(Component.empty());
            extra.add(Msg.noItalic("<dark_gray>▪ <gray>Price: <green><p>", Msg.money("p", l.priceCents())));
            extra.add(Msg.noItalic("<dark_gray>▪ <gray>Seller: <white><s>", Msg.text("s", l.sellerName())));
            extra.add(Msg.noItalic("<dark_gray>▪ <gray>Expires: <yellow><t>", Msg.text("t", Msg.duration(l.expiresAt() - now))));
            extra.add(Component.empty());
            extra.add(Msg.noItalic(mine ? "<red>Shift-right-click to cancel" : "<yellow>Click to buy"));
            getInventory().setItem(i, ItemBuilder.appendLore(l.item(), extra));
            slotToListing.put(i, l.id());
        }

        if (page > 0) getInventory().setItem(PREV, new ItemBuilder(Material.ARROW).name("<yellow>« Previous").build());
        if (page < maxPage(all.size())) getInventory().setItem(NEXT, new ItemBuilder(Material.ARROW).name("<yellow>Next »").build());
        int pending = plugin.auctions().pendingClaims(viewer.getUniqueId());
        getInventory().setItem(CLAIM, new ItemBuilder(Material.CHEST)
                .name("<aqua>Claim Items")
                .lore("<gray>Expired / returned items: <white><n>", Placeholder.unparsed("n", String.valueOf(pending)))
                .glow(pending > 0).build());
        getInventory().setItem(INFO, new ItemBuilder(Material.OAK_SIGN)
                .name("<gradient:#FF5555:#FFAA00>Auction House</gradient>")
                .lore("<gray>Page <white><p><gray>/<white><m>", Placeholder.unparsed("p", String.valueOf(page + 1)), Placeholder.unparsed("m", String.valueOf(maxPage(all.size()) + 1)))
                .lore("<gray>Your listings: <white><c><gray>/<white><x>",
                        Placeholder.unparsed("c", String.valueOf(plugin.auctions().countBy(viewer.getUniqueId()))),
                        Placeholder.unparsed("x", String.valueOf(plugin.auctions().maxListings())))
                .lore("<gray>Sell with <yellow>/ah sell <price>")
                .build());
        fillEmpty();
    }

    @Override
    public void onClick(Player p, InventoryClickEvent e) {
        int slot = e.getSlot();
        if (slot == PREV && page > 0) { page--; render(p); return; }
        if (slot == NEXT) { page++; render(p); return; }
        if (slot == CLAIM) { plugin.auctions().claim(p); render(p); return; }

        UUID id = slotToListing.get(slot);
        if (id == null) return;
        Listing l = plugin.auctions().get(id);
        if (l == null) {
            Msg.send(p, "<red>That listing is no longer available.");
            render(p);
            return;
        }
        if (l.seller().equals(p.getUniqueId())) {
            if (e.getClick() == ClickType.SHIFT_RIGHT && plugin.auctions().cancel(p, l)) {
                Msg.send(p, "<yellow>Listing cancelled. The item was returned to you.");
            } else {
                Msg.send(p, "<gray>That's your listing. <yellow>Shift-right-click <gray>to cancel it.");
            }
            render(p);
            return;
        }

        long now = System.currentTimeMillis();
        if (!id.equals(pending) || now > pendingUntil) { // two-click confirmation against misclicks
            pending = id;
            pendingUntil = now + 5000;
            Msg.send(p, "<yellow>Click again within 5s to buy <item> <yellow>for <green><p><yellow>.",
                    Placeholder.component("item", l.item().displayName()), Msg.money("p", l.priceCents()));
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.3f);
            return;
        }
        pending = null;
        switch (plugin.auctions().buy(p, id)) {
            case SUCCESS -> {
                Msg.send(p, "<green>Purchase complete!");
                p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
            }
            case NO_FUNDS -> Msg.send(p, "<red>You can't afford that.");
            case GONE -> Msg.send(p, "<red>Someone else got there first.");
            case OWN -> Msg.send(p, "<red>You can't buy your own listing.");
        }
        render(p);
    }
}
