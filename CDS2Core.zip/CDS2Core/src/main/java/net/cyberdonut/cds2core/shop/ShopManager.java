package net.cyberdonut.cds2core.shop;

import net.cyberdonut.cds2core.CDS2Core;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ShopManager {

    private final CDS2Core plugin;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();

    public ShopManager(CDS2Core plugin) { this.plugin = plugin; }

    public void load() {
        categories.clear();
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "shop.yml"));
        ConfigurationSection cats = yml.getConfigurationSection("categories");
        if (cats == null) return;
        for (String id : cats.getKeys(false)) {
            ConfigurationSection c = cats.getConfigurationSection(id);
            if (c == null) continue;
            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            if (icon == null || !icon.isItem()) icon = Material.CHEST;
            List<ShopItem> items = new ArrayList<>();
            ConfigurationSection is = c.getConfigurationSection("items");
            if (is != null) {
                for (String key : is.getKeys(false)) {
                    Material m = Material.matchMaterial(key.toUpperCase(Locale.ROOT));
                    ConfigurationSection s = is.getConfigurationSection(key);
                    if (m == null || !m.isItem() || m.isAir() || s == null) {
                        plugin.getLogger().warning("shop.yml: invalid item '" + key + "' in category " + id);
                        continue;
                    }
                    items.add(new ShopItem(m, toCents(s.getDouble("buy", -1)), toCents(s.getDouble("sell", -1))));
                    if (items.size() >= 45) break;
                }
            }
            categories.put(id.toLowerCase(Locale.ROOT), new ShopCategory(id, c.getString("display", id), icon, c.getInt("slot", 13), List.copyOf(items)));
        }
        plugin.getLogger().info("Loaded " + categories.size() + " shop categories.");
    }

    private static long toCents(double dollars) {
        return dollars < 0 ? -1 : Math.round(dollars * 100.0);
    }

    public Collection<ShopCategory> categories() { return categories.values(); }
}
