package net.cyberdonut.cds2core.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class ItemBuilder {

    private final ItemStack stack;
    private Component name;
    private final List<Component> lore = new ArrayList<>();
    private boolean glow;
    private NamespacedKey pdcKey;
    private String pdcValue;

    public ItemBuilder(Material material) {
        this.stack = new ItemStack(material);
    }

    public ItemBuilder amount(int amount) { stack.setAmount(Math.max(1, Math.min(64, amount))); return this; }
    public ItemBuilder name(String mini, TagResolver... r) { this.name = Msg.noItalic(mini, r); return this; }
    public ItemBuilder name(Component c) { this.name = c; return this; }
    public ItemBuilder lore(String mini, TagResolver... r) { lore.add(Msg.noItalic(mini, r)); return this; }
    public ItemBuilder lore(Component c) { lore.add(c); return this; }
    public ItemBuilder lore(List<Component> lines) { lore.addAll(lines); return this; }
    public ItemBuilder glow(boolean glow) { this.glow = glow; return this; }
    public ItemBuilder pdc(NamespacedKey key, String value) { this.pdcKey = key; this.pdcValue = value; return this; }

    public ItemStack build() {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;
        if (name != null) meta.displayName(name);
        if (!lore.isEmpty()) meta.lore(lore);
        if (glow) meta.setEnchantmentGlintOverride(true);
        if (pdcKey != null) meta.getPersistentDataContainer().set(pdcKey, PersistentDataType.STRING, pdcValue);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Returns a clone of base with extra lore lines appended. */
    public static ItemStack appendLore(ItemStack base, List<Component> extra) {
        ItemStack copy = base.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta == null) return copy;
        List<Component> existing = meta.lore();
        List<Component> lore = existing != null ? new ArrayList<>(existing) : new ArrayList<>();
        lore.addAll(extra);
        meta.lore(lore);
        copy.setItemMeta(meta);
        return copy;
    }
}
