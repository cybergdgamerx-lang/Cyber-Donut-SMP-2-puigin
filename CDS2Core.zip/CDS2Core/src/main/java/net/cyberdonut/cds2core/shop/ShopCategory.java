package net.cyberdonut.cds2core.shop;

import org.bukkit.Material;

import java.util.List;

public record ShopCategory(String id, String display, Material icon, int slot, List<ShopItem> items) {}
