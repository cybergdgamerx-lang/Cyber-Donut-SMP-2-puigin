package net.cyberdonut.cds2core.crate;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import net.cyberdonut.cds2core.util.Tab;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

public final class CrateCommand implements TabExecutor {

    private final CDS2Core plugin;

    public CrateCommand(CDS2Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            usage(sender);
            return true;
        }
        CrateManager cm = plugin.crates();
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                Msg.send(sender, "<gradient:#FF5555:#FFAA00>Crates:</gradient>");
                for (Crate c : cm.allCrates()) {
                    sender.sendMessage(Msg.parse("<dark_gray> ▪ <crate> <gray>(<n> placed, <r> rewards)", Placeholder.parsed("crate", c.display()),
                            Placeholder.unparsed("n", String.valueOf(cm.blockCount(c.id()))), Placeholder.unparsed("r", String.valueOf(c.rewards().size()))));
                }
            }
            case "preview" -> {
                if (!(sender instanceof Player p) || args.length != 2) { usage(sender); return true; }
                Crate c = cm.getCrate(args[1]);
                if (c == null) { Msg.send(p, "<red>Unknown crate."); return true; }
                new CratePreviewMenu(plugin, c).open(p);
            }
            case "create" -> {
                if (!sender.hasPermission("cds2.crate.admin")) { Msg.send(sender, "<red>No permission."); return true; }
                if (!(sender instanceof Player p) || args.length != 2) { usage(sender); return true; }
                Crate c = cm.getCrate(args[1]);
                if (c == null) {
                    Msg.send(p, "<red>Unknown crate. Available: <white><list>", Msg.text("list", String.join(", ", cm.crateIds())));
                    return true;
                }
                Block target = p.getTargetBlockExact(6);
                if (target == null || !isCrateMaterial(target.getType())) {
                    Msg.send(p, "<red>Look at a chest, trapped chest, ender chest or barrel (within 6 blocks).");
                    return true;
                }
                if (target.getBlockData() instanceof Chest cd && cd.getType() != Chest.Type.SINGLE) {
                    Msg.send(p, "<red>Double chests can't be crates. Use a single chest.");
                    return true;
                }
                if (cm.isCrateBlock(target)) {
                    Msg.send(p, "<red>That block is already a crate. Use <white>/crate remove <red>first.");
                    return true;
                }
                cm.setCrateBlock(target, c);
                Msg.send(p, "<green>Created a <crate> <green>at the targeted block.", Placeholder.parsed("crate", c.display()));
            }
            case "remove" -> {
                if (!sender.hasPermission("cds2.crate.admin")) { Msg.send(sender, "<red>No permission."); return true; }
                if (!(sender instanceof Player p)) { usage(sender); return true; }
                Block target = p.getTargetBlockExact(6);
                if (target != null && cm.removeCrateBlock(target)) Msg.send(p, "<green>Crate removed.");
                else Msg.send(p, "<red>You're not looking at a crate.");
            }
            default -> usage(sender);
        }
        return true;
    }

    private static boolean isCrateMaterial(Material m) {
        return m == Material.CHEST || m == Material.TRAPPED_CHEST || m == Material.ENDER_CHEST || m == Material.BARREL;
    }

    private void usage(CommandSender s) {
        Msg.send(s, "<red>Usage: <white>/crate <create|remove|list|preview> [name]");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) return Tab.filter(List.of("create", "remove", "list", "preview"), args[0]);
        if (args.length == 2 && (args[0].equalsIgnoreCase("create") || args[0].equalsIgnoreCase("preview"))) {
            return Tab.filter(plugin.crates().crateIds(), args[1]);
        }
        return List.of();
    }
}
