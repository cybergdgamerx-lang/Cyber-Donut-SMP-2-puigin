package net.cyberdonut.cds2core.listener;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.bounty.Bounty;
import net.cyberdonut.cds2core.util.Msg;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class JoinListener implements Listener {

    private final CDS2Core plugin;

    public JoinListener(CDS2Core plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.economy().createAccount(p.getUniqueId(), p.getName());

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            int claims = plugin.auctions().pendingClaims(p.getUniqueId());
            if (claims > 0) {
                Msg.send(p, "<yellow>You have <white><n> <yellow>item(s) waiting. Use <white>/ah claim<yellow>.", Placeholder.unparsed("n", String.valueOf(claims)));
            }
            Bounty b = plugin.bounties().get(p.getUniqueId());
            if (b != null) {
                Msg.send(p, "<red>Watch your back! There is a <gold><amt> <red>bounty on your head.", Msg.money("amt", b.amountCents()));
            }
        }, 40L);
    }
}
