# CDS2Core
All-in-one core plugin for Cyber Donut SMP 2 (Paper 1.21+, Java 21).

Build:  mvn clean package   ->  target/CDS2Core.jar  (drop into /plugins)

Data files (plugins/CDS2Core): balances.yml, auctions.yml, bounties.yml, crate-blocks.yml
Config files: config.yml, shop.yml, crates.yml  (/cds2core reload)

Vault: if Vault is installed, CDS2Core registers itself as the Vault economy provider
(priority Highest), so Vault-based plugins use the same balances.yml. Only keep ONE
economy plugin installed (disable EssentialsX economy etc.) to avoid split balances.
