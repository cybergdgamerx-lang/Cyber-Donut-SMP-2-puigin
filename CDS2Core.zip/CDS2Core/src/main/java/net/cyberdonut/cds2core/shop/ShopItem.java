package net.cyberdonut.cds2core.shop;

import org.bukkit.Material;

/** buyCents / sellCents of -1 mean "disabled". */
public record ShopItem(Material material, long buyCents, long sellCents) {
    public boolean canBuy() { return buyCents >= 0; }
    public boolean canSell() { return sellCents >= 0; }
}
