package net.cyberdonut.cds2core.bounty;

import net.cyberdonut.cds2core.CDS2Core;
import net.cyberdonut.cds2core.util.Msg;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public final class BountyListener implements Listener {

    private final CDS2Core plugin;

    public BountyListener(CDS2Core plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.getUniqueId().equals(victim.getUniqueId())) return;

        Bounty bounty = plugin.bounties().remove(victim.getUniqueId()); // remove first => can only ever pay once
        if (bounty == null) return;

        plugin.economy().deposit(killer.getUniqueId(), bounty.amountCents());
        Msg.broadcast("<white><killer> <gray>claimed the <gold><amt> <gray>bounty on <red><victim><gray>!",
                Msg.text("killer", killer.getName()), Msg.money("amt", bounty.amountCents()), Msg.text("victim", victim.getName()));
        killer.playSound(killer.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
    }
}
